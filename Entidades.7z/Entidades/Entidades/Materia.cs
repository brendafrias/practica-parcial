﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades
{
    public class Materia
    {
        #region Atributos
        private List<Alumno> _alumnos;
        private EMateria _nombre;
        private static Random _notaParaUnAlumno;

        #endregion

        #region Propiedades
        List<Alumno> Alumnos { get { return this._alumnos; } set { this._alumnos = value; } }
        EMateria Nombre { get { return this._nombre; } set { this._nombre = value; } }

        #endregion

        #region Metodos
        public void CalificarAlumnos()
        {
            foreach(Alumno a in this._alumnos)
            {
                a.Nota = _notaParaUnAlumno.Next(0, 10);
            }
        }

        public static explicit operator string(Materia materia)
        {
            return materia.Mostrar(); 
        }

        public static implicit operator float(Materia m)
        {
            float promedio = 0;

            foreach(Alumno a in m._alumnos)
            {
                promedio += a.Nota;
            }

           return promedio / m._alumnos.Count;

        }
        
        public static implicit operator Materia(EMateria nombre)
        {
            Materia m = new Materia(nombre);

            return m;         
        }

        private Materia()
        {
            this._alumnos = new List<Alumno>();
        }

         static Materia()
        {
            _notaParaUnAlumno = new Random();

        }

        private Materia(EMateria nombre) :this()
        {
            this._nombre = nombre;
            
        }

        private string Mostrar()
        {
            string sb;
            sb = "Materia: " + this._nombre;

            foreach(Alumno a in this._alumnos)
            {
                sb += Alumno.Mostrar(a);
            }

            return sb;
        }



        public static bool operator !=(Materia m, Alumno a)
        {
            return !(m == a);
        }

     



        public static Materia operator -(Materia m,Alumno a)
        {
            if (m == a)
            {
               m.Alumnos.RemoveAt(m.Alumnos.IndexOf(a));
            }

            return m;
            
        }


        public static Materia operator +(Materia m, Alumno a)
        {
            if (!(m == a))
            {
                m._alumnos.Add(a);
                
            }

            return m;
          
        }

        public static bool operator ==(Materia m, Alumno a)
        {
          foreach(Alumno alumno in m._alumnos)
            {
                if(alumno == a)
                {
                    return true;
                }
                
            }

            return false;
        }
        #endregion
    }
}
