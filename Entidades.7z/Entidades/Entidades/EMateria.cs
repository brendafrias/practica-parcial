﻿public enum EMateria
{
    Laboratorio_I,
    Laboratorio_II,
    Programacion_I,
    Programacion_II
}