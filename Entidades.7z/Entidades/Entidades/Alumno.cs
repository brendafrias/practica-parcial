﻿using System;

namespace Entidades
{
    public class Alumno
    {
        #region Atributos
        private string _apellido;
        private int _legajo;
        private string _nombre;
        private float _nota;
        #endregion

        #region Propiedades
        public string Apellido { get { return this._apellido; } set { this._apellido = value; } }
        public int Legajo { get { return this._legajo; } set { this._legajo = value; } }
        public string Nombre { get { return this._nombre; } set { this._nombre = value; } }
        public float Nota { get { return this._nota; } set { this._nota = value; } }
        #endregion

        #region Metodos


        public Alumno(int legajo, string nombre, string apellido) : this(legajo,nombre)
        {
            this._apellido = apellido;
            
        }

        public Alumno(int legajo,string nombre) :this(nombre)
        {
            this._legajo = legajo;
        }

        public Alumno(string nombre)
        {
            this._nombre = nombre;
        }

        public Alumno(int legajo)
        {
            this._legajo = legajo;
        }

        public Alumno(string apellido , int legajo) : this(legajo)
        {
            this._apellido = apellido;
        }

      

        private string Mostrar()
        {         
            return this._apellido + "," + this._nombre + "- Legajo: " + this._legajo.ToString() + "- Nota: " + this._nota;
        }

        public static string Mostrar(Alumno alumno)
        {
            return alumno._apellido + "," + alumno._nombre + "- Legajo: " + alumno._legajo.ToString() + "- Nota: " + alumno._nota;
        }

        public static bool operator !=(Alumno a, Alumno b)
        {
            return !(a == b);
        }

        public static bool operator ==(Alumno a, Alumno b)
        {
            if (a._legajo == b._legajo)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        #endregion
    }
}
